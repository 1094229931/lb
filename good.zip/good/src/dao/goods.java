package dao;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Panel;
import java.awt.Label;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class goods extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			goods dialog = new goods();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public goods() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			Panel panel = new Panel();
			panel.setBounds(216, 10, 0, 0);
			contentPanel.add(panel);
			panel.setLayout(null);
		}
		
		Label label = new Label("������");
		label.setBounds(95, 10, 77, 25);
		contentPanel.add(label);
		
		Panel panel = new Panel();
		panel.setBounds(291, 52, 131, 166);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("���");
		btnNewButton.setBounds(14, 23, 113, 27);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(14, 81, 113, 27);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("��ѯ");
		btnNewButton_2.setBounds(14, 139, 113, 27);
		panel.add(btnNewButton_2);
		
		contentPanel.setLayout(null);
		{
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(10, 50, 253, 166);
			contentPanel.add(scrollPane);
			{
				table = new JTable(){
					 public boolean isCellEditable(int row, int column)
	                  {
						 return false;//�����������༭
	                  }
				};
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
						"\u5546\u54C1", "\u8FDB\u8D27\u91CF", "\u51FA\u8D27\u91CF", "\u5E93\u5B58\u91CF"
					}
				) );
				scrollPane.setViewportView(table);
			}
		}
	}
}
