package dao;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class num extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			num dialog = new num();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public num() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("��Ʒ�б�");
			lblNewLabel.setBounds(89, 39, 72, 18);
			contentPanel.add(lblNewLabel);
		}
		
		Panel panel = new Panel();
		panel.setBounds(263, 39, 134, 175);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("������Ʒ");
		btnNewButton.setBounds(14, 13, 113, 27);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ɾ����Ʒ");
		btnNewButton_1.setBounds(14, 53, 113, 27);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("�޸���Ʒ");
		btnNewButton_2.setBounds(14, 93, 113, 27);
		panel.add(btnNewButton_2);
		
		JButton button = new JButton("\u67E5\u8BE2\u5546\u54C1");
		button.setBounds(14, 133, 113, 27);
		panel.add(button);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 70, 243, 144);
		contentPanel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"id", "\u5546\u54C1", "\u8FDB\u4EF7", "\u552E\u4EF7", "\u6570\u91CF"
			}
		));
		scrollPane.setViewportView(table);
	}
}
