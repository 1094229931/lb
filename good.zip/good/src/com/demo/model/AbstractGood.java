package com.demo.model;

/**
 * AbstractGood entity provides the base persistence definition of the Good
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractGood implements java.io.Serializable {

	// Fields

	private GoodId id;
	private Num num;
	private String goods;

	// Constructors

	/** default constructor */
	public AbstractGood() {
	}

	/** minimal constructor */
	public AbstractGood(GoodId id, String goods) {
		this.id = id;
		this.goods = goods;
	}

	/** full constructor */
	public AbstractGood(GoodId id, Num num, String goods) {
		this.id = id;
		this.num = num;
		this.goods = goods;
	}

	// Property accessors

	public GoodId getId() {
		return this.id;
	}

	public void setId(GoodId id) {
		this.id = id;
	}

	public Num getNum() {
		return this.num;
	}

	public void setNum(Num num) {
		this.num = num;
	}

	public String getGoods() {
		return this.goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

}