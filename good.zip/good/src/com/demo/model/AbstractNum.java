package com.demo.model;

/**
 * AbstractNum entity provides the base persistence definition of the Num
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractNum implements java.io.Serializable {

	// Fields

	private NumId id;
	private String goods;
	private Integer number;
	private Good good;

	// Constructors

	/** default constructor */
	public AbstractNum() {
	}

	/** minimal constructor */
	public AbstractNum(NumId id, String goods, Integer number) {
		this.id = id;
		this.goods = goods;
		this.number = number;
	}

	/** full constructor */
	public AbstractNum(NumId id, String goods, Integer number, Good good) {
		this.id = id;
		this.goods = goods;
		this.number = number;
		this.good = good;
	}

	// Property accessors

	public NumId getId() {
		return this.id;
	}

	public void setId(NumId id) {
		this.id = id;
	}

	public String getGoods() {
		return this.goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

	public Integer getNumber() {
		return this.number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Good getGood() {
		return this.good;
	}

	public void setGood(Good good) {
		this.good = good;
	}

}