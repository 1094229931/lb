package com.demo.model;

/**
 * NumId entity. @author MyEclipse Persistence Tools
 */
public class NumId extends AbstractNumId implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public NumId() {
	}

	/** full constructor */
	public NumId(Integer inNum, Integer outNum) {
		super(inNum, outNum);
	}

}
