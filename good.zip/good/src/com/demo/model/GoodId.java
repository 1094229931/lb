package com.demo.model;

/**
 * GoodId entity. @author MyEclipse Persistence Tools
 */
public class GoodId extends AbstractGoodId implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public GoodId() {
	}

	/** full constructor */
	public GoodId(Integer id, Integer inPrice, Integer outPrice) {
		super(id, inPrice, outPrice);
	}

}
