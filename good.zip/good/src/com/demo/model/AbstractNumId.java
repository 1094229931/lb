package com.demo.model;

/**
 * AbstractNumId entity provides the base persistence definition of the NumId
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractNumId implements java.io.Serializable {

	// Fields

	private Integer inNum;
	private Integer outNum;

	// Constructors

	/** default constructor */
	public AbstractNumId() {
	}

	/** full constructor */
	public AbstractNumId(Integer inNum, Integer outNum) {
		this.inNum = inNum;
		this.outNum = outNum;
	}

	// Property accessors

	public Integer getInNum() {
		return this.inNum;
	}

	public void setInNum(Integer inNum) {
		this.inNum = inNum;
	}

	public Integer getOutNum() {
		return this.outNum;
	}

	public void setOutNum(Integer outNum) {
		this.outNum = outNum;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof AbstractNumId))
			return false;
		AbstractNumId castOther = (AbstractNumId) other;

		return ((this.getInNum() == castOther.getInNum()) || (this.getInNum() != null
				&& castOther.getInNum() != null && this.getInNum().equals(
				castOther.getInNum())))
				&& ((this.getOutNum() == castOther.getOutNum()) || (this
						.getOutNum() != null && castOther.getOutNum() != null && this
						.getOutNum().equals(castOther.getOutNum())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getInNum() == null ? 0 : this.getInNum().hashCode());
		result = 37 * result
				+ (getOutNum() == null ? 0 : this.getOutNum().hashCode());
		return result;
	}

}