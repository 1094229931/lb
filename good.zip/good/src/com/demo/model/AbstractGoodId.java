package com.demo.model;

/**
 * AbstractGoodId entity provides the base persistence definition of the GoodId
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractGoodId implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer inPrice;
	private Integer outPrice;

	// Constructors

	/** default constructor */
	public AbstractGoodId() {
	}

	/** full constructor */
	public AbstractGoodId(Integer id, Integer inPrice, Integer outPrice) {
		this.id = id;
		this.inPrice = inPrice;
		this.outPrice = outPrice;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getInPrice() {
		return this.inPrice;
	}

	public void setInPrice(Integer inPrice) {
		this.inPrice = inPrice;
	}

	public Integer getOutPrice() {
		return this.outPrice;
	}

	public void setOutPrice(Integer outPrice) {
		this.outPrice = outPrice;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof AbstractGoodId))
			return false;
		AbstractGoodId castOther = (AbstractGoodId) other;

		return ((this.getId() == castOther.getId()) || (this.getId() != null
				&& castOther.getId() != null && this.getId().equals(
				castOther.getId())))
				&& ((this.getInPrice() == castOther.getInPrice()) || (this
						.getInPrice() != null && castOther.getInPrice() != null && this
						.getInPrice().equals(castOther.getInPrice())))
				&& ((this.getOutPrice() == castOther.getOutPrice()) || (this
						.getOutPrice() != null
						&& castOther.getOutPrice() != null && this
						.getOutPrice().equals(castOther.getOutPrice())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getId() == null ? 0 : this.getId().hashCode());
		result = 37 * result
				+ (getInPrice() == null ? 0 : this.getInPrice().hashCode());
		result = 37 * result
				+ (getOutPrice() == null ? 0 : this.getOutPrice().hashCode());
		return result;
	}

}