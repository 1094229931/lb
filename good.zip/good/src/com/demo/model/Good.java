package com.demo.model;

/**
 * Good entity. @author MyEclipse Persistence Tools
 */
public class Good extends AbstractGood implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Good() {
	}

	/** minimal constructor */
	public Good(GoodId id, String goods) {
		super(id, goods);
	}

	/** full constructor */
	public Good(GoodId id, Num num, String goods) {
		super(id, num, goods);
	}

}
