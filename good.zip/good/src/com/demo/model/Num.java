package com.demo.model;

/**
 * Num entity. @author MyEclipse Persistence Tools
 */
public class Num extends AbstractNum implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Num() {
	}

	/** minimal constructor */
	public Num(NumId id, String goods, Integer number) {
		super(id, goods, number);
	}

	/** full constructor */
	public Num(NumId id, String goods, Integer number, Good good) {
		super(id, goods, number, good);
	}

}
