package factory;

public class numbercontrol {

}
