package factory;

import java.util.List;

import org.hibernate.Session;

import com.demo.model.GoodId;
import com.demo.model.HibernateSessionFactory;
import com.demo.model.Good;
import com.demo.model.GoodDAO;

public class GoodControl {
	public static GoodControl control = null;
	public static GoodControl getControl()
	{
		if(control==null)
			control  = new GoodControl();
		return control;
	}
	
	private Session session;
	private GoodDAO gooddao;
	
	public GoodControl()
	{
		session = HibernateSessionFactory.getSession();
		gooddao = new GoodDAO();
	}
	public Good findByGoodsID(GoodId ID)
	{
		try
		{
			return gooddao.findById(ID);
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public List<Good> findByName(GoodId name)
	{
		try
		{
			return (List<Good>) gooddao.findById(name);
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public List<Good> findAll()
	{
		try
		{
			return gooddao.findAll();
		}catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	public boolean save(Good Goods)
	{
		try{
			gooddao.save(Goods);
    		session.beginTransaction().commit();
    		session.flush();
    		return true;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}
	}
	public boolean delete(Good Goods)
	{
		try{
			gooddao.delete(Goods);
    		session.beginTransaction().commit();
    		session.flush();
    		return true;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}
	}
	public boolean update(Good Goods)
	{
		try{
			gooddao.merge(Goods);
    		session.beginTransaction().commit();
    		session.flush();
    		return true;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return false;
    	}
	}
}

